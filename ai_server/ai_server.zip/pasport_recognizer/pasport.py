import cv2
import easyocr

# JSON-список с информацией о пассажирах
passenger_data = [
    3,
    {
        "FIO": ["карелин", "иван", "сергеевич"],
        "seat": 1,
        "van": 1
    },
    {
        "FIO": ["кирюхин", "дмитрий", "александрович"],
        "seat": 2,
        "van": 1
    },
    {
        "FIO": ["макеев", "дмитрий", ""],
        "seat": 3,
        "van": 1
    }
]

# Инициализация EasyOCR
reader = easyocr.Reader(['ru'], gpu=False)

# Параметры рамки для захвата паспорта
frame_width, frame_height = 400, 200
frame_x, frame_y = 100, 100

def process_frame(frame):
    """Обрезка кадра по области рамки."""
    return frame[frame_y:frame_y + frame_height, frame_x:frame_x + frame_width]

def preprocess_image(image):
    """Улучшение изображения для OCR."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Корректировка яркости и контраста
    normalized = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)
    # Применение адаптивной бинаризации
    binary = cv2.adaptiveThreshold(normalized, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    return binary

def recognize_passport_text(image):
    """Распознавание текста на изображении."""
    preprocessed_image = preprocess_image(image)
    cv2.imshow("Проверка обработки", preprocessed_image)
    cv2.waitKey(1)  # Для отображения окна
    results = reader.readtext(preprocessed_image, paragraph=True, detail=0)
    print("Результаты EasyOCR:", results)
    return " ".join(results).lower()

def match_passenger_info(recognized_text):
    """Сопоставление распознанного текста с данными пассажиров."""
    recognized_words = set(recognized_text.split())

    for passenger in passenger_data[1:]:
        fio = set(passenger["FIO"])
        if fio.issubset(recognized_words):
            return passenger["van"], passenger["seat"]

    return None, None

def main():
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Не удалось получить доступ к камере")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Не удалось получить изображение с камеры")
            break

        # Отрисовка рамки
        cv2.rectangle(
            frame, 
            (frame_x, frame_y), 
            (frame_x + frame_width, frame_y + frame_height), 
            (0, 255, 0), 2
        )
        cv2.putText(
            frame, 
            "Поместите паспорт в рамку", 
            (frame_x, frame_y - 10), 
            cv2.FONT_HERSHEY_SIMPLEX, 
            0.6, 
            (0, 255, 0), 
            2
        )

        # Отображение кадра
        cv2.imshow("Кадр с камеры", frame)

        # Обработка при нажатии 's'
        if cv2.waitKey(1) & 0xFF == ord('s'):
            passport_frame = process_frame(frame)

            # Вывод обрезанного изображения для отладки
            cv2.imshow("Обрезанное изображение", passport_frame)
            cv2.waitKey(1)  # Для отображения окна

            recognized_text = recognize_passport_text(passport_frame)
            print("Распознанный текст:", recognized_text)

            van, seat = match_passenger_info(recognized_text)

            if van and seat:
                print(f"Ваш вагон: {van}, ваше место: {seat}")
            else:
                print("Извините, вас нет в списке пассажиров, обратитесь за справкой к проводнику")

        # Выход при нажатии 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("quit")
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
